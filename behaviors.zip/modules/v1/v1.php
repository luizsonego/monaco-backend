<?php
namespace app\modules\v1;

use yii\base\Module;

// Created By @hoaaah * Copyright (c) 2020 belajararief.com

class v1 extends Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'app\modules\v1\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
